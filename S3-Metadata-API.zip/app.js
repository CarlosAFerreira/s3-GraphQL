const { MongoClient } = require('mongodb');

exports.lambdaHandler = async (event, context, callback) => {
    // Initializes connection parameter to MongoDB and our item array to be returned
    console.log("Inicio da execucao da funcao de Pesquisa dos metadados");
    const listOfTickets = [];
    const uri = process.env.MONGODB_URI;
    const client = new MongoClient(uri,{ useUnifiedTopology: true });
    var condition = {};
    console.log("Client instanciado");
    switch(event.field) {
        case "getTicketsbyProtocol":
            try {
                
                console.log("inicio da execucao do tipo getTicketsbyProtocol");
                
                // Extract argument we need that was passed in as event 
                const idprotocol = event.arguments.idprotocol;
                // Connect to our MongoDB instance and execute the query
                await client.connect();
                
                console.log("busca dados da pesquisa");
                
                condition = {};
                
                if (idprotocol != "" && idprotocol != null && idprotocol != undefined) {
                    condition = Object.assign(condition, {idprotocol:idprotocol});
                }
                
                console.log("condition", condition);
                            
                //const cursor = client.db('historico').collection('historico-atendimento').find(condition);

                const cursor = client.db('historico').collection("historico-atendimento").aggregate([
                {
                    "$match": condition
                },
                {
                    "$group": {
                        "_id": {"idprotocol":"$idprotocol", "key":"$key"},
                        "key": {"$last": "$key"},
                        "idprotocol": {"$last": "$idprotocol"},
                        "channel": { "$last": "$channel"},
                        "person" : { "$last": "$person"},
                        "closedat": { "$last": "$closedat" },
                        "idsource": { "$last": "$idsource" },
                        "attachment" : { "$last": "$attachment"},        
                        "dsource"    : { "$last": "$dsource"},
                        "csat"    : { "$last": "$csat"}
                    }   
                }
                ]);

                const results = await cursor.toArray();
                // If we get items from our database, we add them to our result array one-by-one
                if (results.length > 0) {
                    console.log("Pesquisa retornou itens");
                    results.forEach((result) => {
                        // Create ticket object for each returned ticket result from DB
                        listOfTickets.push({
                            key:result.key,
                            channel:result.channel,
                            person:result.person,
                            idprotocol:result.idprotocol,
                            closedat:result.closedat,
                            idsource:result.idsource,
                            attachment:result.attachment,
                            dsource:result.dsource,
                            csat:result.csat
                            });
                        });
                    }
                // Close our DB connection before exiting execution
                console.log("teste",listOfTickets);
                await client.close();
                // Return results by using the callback function provided, pass in our error(null in this case) and response
                callback(null, listOfTickets);
                break;
            } catch (err) {
                console.log(err);
                await client.close();
                // Return error by calling callback function and pass in error
                callback(null, err);
                break;
            }
        case "getTicketsbyPerson":
            try {
                // Extract argument we need that was passed in as event 
                const person = event.arguments.person;
                // Connect to our MongoDB instance and execute the query
                await client.connect();
                //const cursor = client.db('historico').collection('historico-atendimento').find({
                //    person: person
                //});
                
                condition = {};
                
                if (person != "" && person != null && person != undefined) {
                    condition = Object.assign(condition, {person:person});
                }                
                
                const cursor = client.db('historico').collection("historico-atendimento").aggregate([
                {
                    "$match": condition
                },
                {
                    "$group": {
                        "_id": {"idprotocol":"$idprotocol", "key":"$key"},
                        "key": {"$last": "$key"},
                        "idprotocol": {"$last": "$idprotocol"},
                        "channel": { "$last": "$channel"},
                        "person" : { "$last": "$person"},
                        "closedat": { "$last": "$closedat" },
                        "idsource": { "$last": "$idsource" },
                        "attachment" : { "$last": "$attachment"},        
                        "dsource"    : { "$last": "$dsource"},
                        "csat"    : { "$last": "$csat"}
                    }   
                }
                ]);
                
                const results = await cursor.toArray();
                // If we get items from our database, we add them to our result array one-by-one
                if (results.length > 0) {
                    results.forEach((result) => {
                        // Create movie object for each returned movie result from DB
                        listOfTickets.push({
                            key:result.key,
                            channel:result.channel,
                            person:result.person,
                            idprotocol:result.idprotocol,
                            closedat:result.closedat,
                            idsource:result.idsource,
                            attachment:result.attachment,
                            dsource:result.dsource,
                            csat:result.csat
                            });
                        });
                    }
                // Close our DB connection before exiting execution
                await client.close();
                // Return results by using the callback function provided, pass in our error(null in this case) and response
                callback(null, listOfTickets);
                break;
            } catch (err) {
                console.log(err);
                await client.close();
                // Return error by calling callback function and pass in error
                callback(null, err);
                break;
            }
        case "getTicketsbyInterval":
            try {
                // Extract argument we need that was passed in as event 
                const person = event.arguments.person;
                const dt_ini = event.arguments.dt_ini;
                const dt_end = event.arguments.dt_end;
                // Connect to our MongoDB instance and execute the query
                await client.connect();
                
                condition = {};
                
                if (person != "" && person != null && person != undefined) {
                    condition = Object.assign(condition, {person:person});
                }
                
				condition = Object.assign(condition, { closedat: { $gte : dt_ini, 
				                                                   $lt  : dt_end}});
				                                                   
				console.log ("condition", condition);                                                   
                
                //const cursor = client.db('historico').collection('historico-atendimento').find(condition);
                
                const cursor = client.db('historico').collection("historico-atendimento").aggregate([
                {
                    "$match": condition
                },
                {
                    "$group": {
                        "_id": {"idprotocol":"$idprotocol", "key":"$key"},
                        "key": {"$last": "$key"},
                        "idprotocol": {"$last": "$idprotocol"},
                        "channel": { "$last": "$channel"},
                        "person" : { "$last": "$person"},
                        "closedat": { "$last": "$closedat" },
                        "idsource": { "$last": "$idsource" },
                        "attachment" : { "$last": "$attachment"},        
                        "dsource"    : { "$last": "$dsource"},
                        "csat"    : { "$last": "$csat"}
                    }   
                }
                ]);
                
                const results = await cursor.toArray();
                // If we get items from our database, we add them to our result array one-by-one
                if (results.length > 0) {
                    results.forEach((result) => {
                        // Create movie object for each returned movie result from DB
                        listOfTickets.push({
                            key:result.key,
                            channel:result.channel,
                            person:result.person,
                            idprotocol:result.idprotocol,
                            closedat:result.closedat,
                            idsource:result.idsource,
                            attachment:result.attachment,
                            dsource:result.dsource,
                            csat:result.csat,
                            });
                        });
                    }
                // Close our DB connection before exiting execution
                await client.close();
                // Return results by using the callback function provided, pass in our error(null in this case) and response
                callback(null, listOfTickets);
                break;
            } catch (err) {
                console.log(err);
                await client.close();
                // Return error by calling callback function and pass in error
                callback(null, err);
                break;
            }
            
// ***********
        case "getTicketsbyCSAT":
            try {
                // Extract argument we need that was passed in as event 
				const channel= event.arguments.channel;
				const dsource= event.arguments.dsource;
				const csat	 = event.arguments.csat;
                const dt_ini = event.arguments.dt_ini;
                const dt_end = event.arguments.dt_end;
				
				condition = {attachment:"false"}; //Define a variaval aceitando apenas objetos de texto
				
				if (channel != "" && channel != null && channel != undefined) {
                    condition = Object.assign(condition, {channel:channel});
                }
				
				if (dsource != "" && dsource != null && dsource != undefined) {
                    condition = Object.assign(condition, {dsource:dsource});
                }
				
				if (csat != "" && csat != null && csat != undefined) {
				    if (csat != "nulo")
                        condition = Object.assign(condition, {csat:csat});
                    else
                       condition = Object.assign(condition, {csat:null});
                }
				
				condition = Object.assign(condition, { closedat: { $gte : dt_ini, 
				                                                   $lt  : dt_end}}); 
				
				console.log ("condition",condition);                                                   
                // Connect to our MongoDB instance and execute the query
                await client.connect();
                //const cursor = client.db('historico').collection('historico-atendimento').find(condition);
                
                const cursor = client.db('historico').collection("historico-atendimento").aggregate([
                {
                    "$match": condition
                },
                {
                    "$group": {
                        "_id": {"idprotocol":"$idprotocol", "key":"$key"},
                        "key": {"$last": "$key"},
                        "idprotocol": {"$last": "$idprotocol"},
                        "channel": { "$last": "$channel"},
                        "person" : { "$last": "$person"},
                        "closedat": { "$last": "$closedat" },
                        "idsource": { "$last": "$idsource" },
                        "attachment" : { "$last": "$attachment"},        
                        "dsource"    : { "$last": "$dsource"},
                        "csat"    : { "$last": "$csat"}
                    }   
                }
                ]);
                
                const results = await cursor.toArray();
                // If we get items from our database, we add them to our result array one-by-one
                if (results.length > 0) {
                    results.forEach((result) => {
                        // Create movie object for each returned movie result from DB
                        listOfTickets.push({
                            key:result.key,
                            channel:result.channel,
                            person:result.person,
                            idprotocol:result.idprotocol,
                            closedat:result.closedat,
                            idsource:result.idsource,
                            attachment:result.attachment,
                            dsource:result.dsource,
                            csat:result.csat,
                            });
                        });
                    }
                // Close our DB connection before exiting execution
                await client.close();
                // Return results by using the callback function provided, pass in our error(null in this case) and response
                callback(null, listOfTickets);
                break;
            } catch (err) {
                console.log(err);
                await client.close();
                // Return error by calling callback function and pass in error
                callback(null, err);
                break;
            }

        case "getResumoCSAT":
            try {
                // Extract argument we need that was passed in as event 
				const channel= event.arguments.channel;
				const csat	 = event.arguments.csat;
                const dt_ini = event.arguments.dt_ini;
                const dt_end = event.arguments.dt_end;
				
				condition = {attachment:"false"}; //Define a variaval aceitando apenas objetos de texto
				
				if (channel != "" && channel != null && channel != undefined) {
                    condition = Object.assign(condition, {channel:channel});
                }
				
				if (csat != "" && csat != null && csat != undefined) {
                    condition = Object.assign(condition, {csat:csat});
                }
				
				condition = Object.assign(condition, { closedat: { $gte : dt_ini, 
				                                                   $lt  : dt_end}}); 
				
				console.log ("condition",condition);                                                   
                // Connect to our MongoDB instance and execute the query
                await client.connect();
                //const cursor = client.db('historico').collection('historico-atendimento').find(condition);

                const cursor = client.db('historico').collection("historico-atendimento").aggregate([
                {
                    "$match": condition
                },
                {
                    "$group": {
                        "_id": {"idprotocol":"$idprotocol"},
                        "channel": { "$last": "$channel"},
                        "csat": { "$last": "$csat"},
                        "count":{"$sum":1}
                    }
                },
                {
                    "$group": {
                        "_id": {"channel": "$channel", "csat":"$csat"},
                        "count":{"$sum":1}
                    }
                }
                ]);

                const results = await cursor.toArray();
                // If we get items from our database, we add them to our result array one-by-one
                if (results.length > 0) {
                    results.forEach((result) => {
                        // Create movie object for each returned movie result from DB
                        listOfTickets.push({
                            channel:result._id.channel,
                            csat:result._id.csat,
                            total:result.count
                            });
                        });
                    }
                // Close our DB connection before exiting execution
                await client.close();
                // Return results by using the callback function provided, pass in our error(null in this case) and response
                callback(null, listOfTickets);
                break;
            } catch (err) {
                console.log(err);
                await client.close();
                // Return error by calling callback function and pass in error
                callback(null, err);
                break;
            }

        default:
            console.log("Campo Desconhecido");
            callback("Campo desconhecido, não é possivel resolver " + event.field, null);
            break;
    }
};