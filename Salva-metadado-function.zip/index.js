console.log('Carregando a funcao de exportacao de metadados');
const aws = require('aws-sdk');
const MongoClient = require('mongodb').MongoClient;
const uri = process.env.MONGODB_URI;
var mgdb = process.env.MONGODB_DATABASE;
var mgdb_collection = process.env.MONGODB_COLLECTION;
const s3 = new aws.S3({ apiVersion: '2020-05-31' });


async function persistMetadata(client, metadata) {
    var collection = client.db(mgdb).collection(mgdb_collection);
    await collection.insertOne(metadata);
}

exports.handler = async (event, context) => {

    const bucket = event.Records[0].s3.bucket.name;
    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    const params = {
        Bucket: bucket,
        Key: key
    };
        
        const { Metadata }  = await s3.getObject(params).promise();
        // Conecta ao MongoDb para persistir a conexao
        console.log("Metadata: ", Metadata);

        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        console.log("=> Intancia um client MongoDb");
        
    try {
        // Conexao efetuada com sucesso
        await client.connect();
        console.log("=> Conexao efetuada com sucesso.");
    
        // Persiste os dados no banco de dados
        await persistMetadata(client,Metadata);
 
    } catch (e) {
        console.error(e);
    } finally {
        await client.close();
    }
};



        