const { URLSearchParams } = require("url");

const TOKENS = ["LFSD84KF8FKS48FD"];

const handler = async (event) => {
	const { request } = event.Records[0].cf;
	const qs = new URLSearchParams(request.querystring);
	
	const token = qs.get("token");

	if (!token || !TOKENS.includes(token)) {
		return {
			status : "403",
			bodyEncoding : "text",
			body: JSON.stringify ({
				error: "forbidden",
			}, null, 2),
		};
	}
	return request;
};
exports.handler = handler;